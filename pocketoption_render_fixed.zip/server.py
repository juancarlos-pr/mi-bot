import os
import threading
import time

from flask import Flask, jsonify, request, send_from_directory
from pocketoptionapi import PocketOption

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")

app = Flask(__name__, static_folder=PUBLIC_DIR, static_url_path="")

ASSET = os.getenv("PO_ASSET", "EURUSD_otc").strip() or "EURUSD_otc"

try:
    PERIOD = int(os.getenv("PO_PERIOD", "60"))
except (TypeError, ValueError):
    PERIOD = 60

try:
    PORT = int(os.getenv("PORT", "10000"))
except (TypeError, ValueError):
    PORT = 10000

api = None
api_lock = threading.Lock()
cache = []
cache_lock = threading.Lock()
worker_started = False
worker_lock = threading.Lock()


def disconnect_api():
    global api
    current = api
    api = None
    if current is not None:
        try:
            current.disconnect_websocket()
        except Exception:
            pass


def connect():
    global api

    ssid = os.getenv("PO_SSID", "").strip()
    if not ssid:
        raise RuntimeError("PO_SSID no esta configurado en Render")

    with api_lock:
        disconnect_api()

        client = PocketOption(ssid)
        result = client.connect()

        if isinstance(result, tuple):
            ok = bool(result[0])
            err = result[1] if len(result) > 1 else None
        else:
            ok = bool(result)
            err = None

        if not ok:
            try:
                client.disconnect_websocket()
            except Exception:
                pass
            raise RuntimeError(f"No se pudo conectar a Pocket Option: {err}")

        api = client

    for _ in range(300):
        current = api
        try:
            if current and current.check_connect() and current.is_time_synced():
                break
        except Exception:
            pass
        time.sleep(0.1)
    else:
        disconnect_api()
        raise RuntimeError("No se pudo sincronizar el tiempo de Pocket Option")

    current = api
    try:
        current.subscribe(ASSET, period=PERIOD)
    except Exception as exc:
        print(f"Advertencia subscribe: {type(exc).__name__}: {exc}", flush=True)

    print(f"Pocket Option conectado: {ASSET} / {PERIOD}s", flush=True)


def normalize_timestamp(value):
    try:
        if value is None or isinstance(value, bool):
            return None
        number = float(value)
        if number > 10_000_000_000:
            number /= 1000.0
        if number <= 0:
            return None
        return int(number)
    except (TypeError, ValueError):
        return None


def get_candles():
    current = api
    if current is None:
        return []

    try:
        if not current.check_connect() or not current.is_time_synced():
            return []

        data = current.get_historical_candles(
            ASSET,
            period=PERIOD,
            offset=45000,
            count_request=1,
        )
    except Exception as exc:
        print(f"Error obteniendo velas: {type(exc).__name__}: {exc}", flush=True)
        return []

    if not data:
        return []

    if isinstance(data, dict):
        if isinstance(data.get("candles"), (list, tuple)):
            data = data["candles"]
        elif isinstance(data.get("data"), (list, tuple)):
            data = data["data"]
        else:
            data = [data]

    if not isinstance(data, (list, tuple)):
        return []

    result = []

    for candle in data:
        if not isinstance(candle, dict):
            continue

        try:
            timestamp = normalize_timestamp(
                candle.get("timestamp", candle.get("time", candle.get("t")))
            )
            open_price = candle.get("open", candle.get("o"))
            high_price = candle.get("high", candle.get("h"))
            low_price = candle.get("low", candle.get("l"))
            close_price = candle.get("close", candle.get("c"))

            if timestamp is None:
                continue
            if any(v is None for v in (open_price, high_price, low_price, close_price)):
                continue

            result.append({
                "timestamp": timestamp,
                "open": float(open_price),
                "high": float(high_price),
                "low": float(low_price),
                "close": float(close_price),
            })
        except (TypeError, ValueError):
            continue

    unique = {item["timestamp"]: item for item in result}
    result = list(unique.values())
    result.sort(key=lambda item: item["timestamp"])
    return result[-500:]


def worker():
    global api

    print("Worker de mercado iniciado", flush=True)

    while True:
        try:
            current = api
            connected = False
            synced = False

            if current is not None:
                try:
                    connected = bool(current.check_connect())
                    synced = bool(current.is_time_synced())
                except Exception:
                    pass

            if not connected or not synced:
                print("Reconectando a Pocket Option...", flush=True)
                connect()

            candles_data = get_candles()

            if candles_data:
                with cache_lock:
                    cache.clear()
                    cache.extend(candles_data)
                print(f"Velas recibidas: {len(candles_data)}", flush=True)

        except Exception as exc:
            print(f"Worker error: {type(exc).__name__}: {exc}", flush=True)
            api = None
            time.sleep(5)

        time.sleep(2)


def start_worker():
    global worker_started

    with worker_lock:
        if worker_started:
            return
        worker_started = True

    threading.Thread(
        target=worker,
        name="pocket-option-worker",
        daemon=True,
    ).start()


@app.get("/")
def index():
    index_file = os.path.join(PUBLIC_DIR, "index.html")
    if not os.path.isfile(index_file):
        return jsonify({
            "status": "ok",
            "message": "Servidor funcionando. Falta public/index.html",
        })
    return send_from_directory(PUBLIC_DIR, "index.html")


@app.get("/api/candles")
def candles():
    asset = request.args.get("asset", ASSET).strip()
    if asset != ASSET:
        return jsonify([])

    with cache_lock:
        return jsonify(list(cache))


@app.get("/api/status")
def status():
    current = api
    connected = False
    synced = False

    if current is not None:
        try:
            connected = bool(current.check_connect())
            synced = bool(current.is_time_synced())
        except Exception:
            pass

    with cache_lock:
        candle_count = len(cache)

    return jsonify({
        "status": "ok",
        "connected": connected,
        "time_synced": synced,
        "asset": ASSET,
        "period": PERIOD,
        "candles": candle_count,
        "ssid_configured": bool(os.getenv("PO_SSID", "").strip()),
    })


@app.get("/health")
def health():
    return jsonify({"status": "ok"}), 200


# Important: Render uses Gunicorn, which imports server:app.
# Start the market worker at import time so it also runs under Gunicorn.
start_worker()


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=PORT,
        debug=False,
        use_reloader=False,
    )
